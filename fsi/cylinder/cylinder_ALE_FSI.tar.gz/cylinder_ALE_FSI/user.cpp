#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <math.h>
    extern "C" {
      void user_cplBC_FINDF_(int& nFaces, int& nX, double* x, double* f, double *Q, double *P, double *offset, int& nXprint, double *Xprint,double* tt);
    }


  void user_cplBC_FINDF_(int& nFaces, int& nX, double& t,double& told, double* x, double* f, double *Q, double *P, double *offset, int& nXprint, double *Xprint){

     double R=700.0;
     double C=0.000030;
     double Rd=1000.0;
     double Pd=1330.0;

     f[0]=-cos(5.0*3.14*t)*3.14*5.0;
     f[1]=(Q[0]-(x[1]-Pd)/Rd)/C;
     offset[1]=Q[0]*R;

     Xprint[0]=t;
     Xprint[1]=Q[0];
     Xprint[2]=offset[1]+x[1];


  }
